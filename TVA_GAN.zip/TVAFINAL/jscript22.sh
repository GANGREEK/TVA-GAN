#!/bin/bash

####prerungl

#PBS -u satish
#PBS -N nand
#PBS -l select=1:ncpus=20:ngpus=1
#PBS -e error.log
#PBS -o output.log
#PBS -q gpu


module use /home/satish/privatemodules/
module load torch12

cd $PBS_O_WORKDIR

#python test.py --dataroot ./datasets/TH  --name THALSYNFCST --model per_cycle_gan --no_dropout --gpu_ids 0  --display_id 0 --dataset_mode aligned &
#python test.py --dataroot ./datasets/WHU  --name WHUALSYNFCST --model per_cycle_gan --no_dropout --gpu_ids 1  --display_id 0 --dataset_mode aligned #&&


python3 train.py --dataroot ./datasets/TH  --name THALSYNFCSTCORB --model per_cycle_gan --no_dropout --gpu_ids 0  --display_id 0 --dataset_mode aligned # &
#python3 train.py --dataroot ./datasets/WHU  --name WHUALSYNFCSTC2 --model per_cycle_gan --no_dropout --gpu_ids 0  --display_id 0 --dataset_mode aligned


python test_.py 

#python3 train.py --dataroot ./datasets/KV_IIITA  --name KVIIITA --model per_cycle_gan --no_dropout --gpu_ids 0,1 --display_id 0 --dataset_mode aligned &&


#python3 train.py --dataroot ./datasets/NIRDATA  --name NIR_OUR --model per_cycle_gan --no_dropout --gpu_ids 0,1  --display_id 0 --dataset_mode aligned




#python train.py --dataroot ./datasets/KV_IIITA --name  KVIIITA --model per_cycle_gan --no_dropout --gpu_ids 0,1  --display_id 0 --dataset_mode aligned #&&

#python test.py --dataroot ./datasets/WHU --name WHU_23 --model per_cycle_gan --no_dropout --gpu_ids 0  --display_id 0 --dataset_mode aligned

#python3 train.py --dataroot ./datasets/NIRDATA  --name NIR_23 --model per_cycle_gan --no_dropout --gpu_ids 0,1  --display_id 0 --dataset_mode aligned &&

#python3 train.py --dataroot ./datasets/WHU  --name WHU_23 --model per_cycle_gan --no_dropout --gpu_ids 0,1  --display_id 0 --dataset_mode aligned &&

#python3 test.py --dataroot ./datasets/WHU --name WHU_OUR --phase test --no_dropout --display_id 0 --how_many 600 --dataset_mode aligned
#python3 test.py --dataroot ./datasets/CUCK --name CUCK_OUR --phase test --no_dropout --display_id 0 --how_many 600 --dataset_mode aligned
#python test.py --dataroot ./datasets/WHU --name WHU_OURSMBOTH --model per_cycle_gan --no_dropout --gpu_ids 0  --display_id 0 --dataset_mode aligned &&

#python test.py --dataroot ./datasets/CHILD --name CHILD_22 --model per_cycle_gan --no_dropout --gpu_ids 0  --display_id 0 --dataset_mode aligned
#&&


#
#mpirun -np 2 python child.py 
#python  test.py --dataroot ./datasets/WHU --name WHU_15 --model attention_gan  --dataset_mode aligned --norm instance --phase test --no_dropout --load_size 256 --crop_size 256 --batch_size 1 --gpu_ids 0 --num_test 1000000000 --saveDisk
#bash  /home/satish/nand/AttentionGAN/scripts/train_attentiongan.sh 
#python  train.py --dataroot ./datasets/WHU --name WHU_AL --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 0 --lambda_B 0 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 1 --gpu_ids 0 --niter 60 --niter_decay 0  &&
#python  test.py --dataroot ./datasets/WHU --name WHU_AL --model attention_gan  --dataset_mode aligned --norm instance --phase test --no_dropout --load_size 286 --crop_size  256  --batch_size 1 --gpu_ids 0 --num_test 1000000000 --saveDisk  #&&  
#python  train.py --dataroot ./datasets/WHU --name WHU_ALCLNEWID --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 2 --gpu_ids 0,1 --niter 60 --niter_decay 0  &&
#python  train.py --dataroot ./datasets/CUCK --name CUCK_ALCLNEWID --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 2 --gpu_ids 0,1 --niter 60 --niter_decay 0 &&
#python  test.py --dataroot ./datasets/WHU --name WHU_ALCLNEWID --model  attention_gan  --dataset_mode aligned --norm instance --phase test --no_dropout --load_size 286 --crop_size  256  --batch_size 1 --gpu_ids 1 --num_test 1000000000 --saveDisk &&

#python  test.py --dataroot ./datasets/CUCK --name CUCK_ALCLNEWID --model  attention_gan  --dataset_mode aligned --norm instance --phase test --no_dropout --load_size 286 --crop_size  256  --batch_size 1 --gpu_ids 1 --num_test 1000000000 --saveDisk 
#python  train.py --dataroot ./datasets/WHU --name WHU_ALCLID --model  alclid --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 1 --gpu_ids 0,1 --niter 60 --niter_decay 0  &&
#python  test.py --dataroot ./datasets/WHU --name WHU_ALCLID --model  alclid  --dataset_mode aligned --norm instance --phase test --no_dropout --load_size 286 --crop_size  256  --batch_size 1 --gpu_ids 1 --num_test 1000000000 --saveDisk
#python  train.py --dataroot ./datasets/WHU --name WHU_new565 --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 1  --gpu_ids 0,1 --niter 60 --niter_decay 0   &&
#python  test.py --dataroot ./datasets/WHU --name WHU_new565 --model attention_gan  --dataset_mode aligned --norm instance --phase test --no_dropout --load_size 286 --crop_size 256  --batch_size 1 --gpu_ids 0,1 --num_test 1000000000 --saveDisk 
#&& python  test.py --dataroot ./datasets/CUCK --name CUCK_new2 --model attention_gan  --dataset_mode aligned --norm instance --phase test --no_dropout --load_size 216 --crop_size    200 --batch_size 1 --gpu_ids 1 --num_test 1000000000 --saveDisk


