
python3 train.py --dataroot ./datasets/WHU  --name WHUALSYNF2 --model TVAGANModel --no_dropout --gpu_ids 1  --display_id 0 --dataset_mode aligned 

